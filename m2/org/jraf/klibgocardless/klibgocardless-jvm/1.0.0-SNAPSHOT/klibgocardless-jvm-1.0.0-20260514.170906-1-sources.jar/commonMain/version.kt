// Generated file. Do not edit!
package org.jraf.klibgocardless
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.0.0-SNAPSHOT"
